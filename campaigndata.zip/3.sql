SELECT location, SUM(impressions) AS total_impressions
FROM marketing_campaign
GROUP BY location
ORDER BY total_impressions DESC
LIMIT 3;