SELECT campaign_id, 
       company, 
       (CAST(REPLACE(REPLACE(acquisition_cost, '$', ''), ',', '') AS NUMERIC) / conversion_rate) AS cost_per_conversion
FROM marketing_campaign
WHERE conversion_rate > 0
ORDER BY cost_per_conversion ASC
LIMIT 1;