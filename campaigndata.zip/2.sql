SELECT campaign_id, company, roi
FROM marketing_campaign
ORDER BY roi DESC
LIMIT 1;