SELECT target_audience, AVG(engagement_score) AS avg_engagement_score
FROM marketing_campaign
GROUP BY target_audience;