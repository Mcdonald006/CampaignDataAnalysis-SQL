SELECT channel_used, SUM(conversion_rate) AS total_conversions
FROM marketing_campaign
GROUP BY channel_used
ORDER BY total_conversions DESC;