SELECT campaign_id, company, (clicks * 100.0 / impressions) AS ctr
FROM marketing_campaign
WHERE (clicks * 100.0 / impressions) > 5; 