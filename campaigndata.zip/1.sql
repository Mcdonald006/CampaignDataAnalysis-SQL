SELECT campaign_id, SUM(impressions) AS total_impressions
FROM marketing_campaign
GROUP BY campaign_id;