SELECT (SUM(clicks)::FLOAT / SUM(impressions)) * 100 AS overall_ctr
FROM marketing_campaign;